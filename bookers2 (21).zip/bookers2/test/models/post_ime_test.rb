require 'test_helper'

class PostImeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
