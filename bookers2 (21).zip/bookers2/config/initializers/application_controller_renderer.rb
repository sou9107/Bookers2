# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'a7ee06f70fe1bdb3a1dc7c7487d7ac244093bf539ff1b4b4ca55a173e285e3e8a5dffbf82961bcf4697e03757f25aa847868aeefc519dad540a46b6ed21f2b31'
